"""
   CheckName: Ensure that S3 logging is enabled
   CheckId: 85be9a17-bfd9-4372-be7e-f10834088013
"""

import json
import boto3
"""
CheckName: Ensure that S3 logging is enabled
CheckId:85be9a17-bfd9-4372-be7e-f10834088013
"""

import sys
from raise_sns_notification import *
import os
import logging
from botocore.exceptions import ClientError


""" Initializing logger and setting log level """

logger = logging.getLogger()
logger.setLevel(logging.INFO)



def lambda_handler(event, context):
    
    """ Main lambda handler responsible for listening to event and
        creating output sns notification."""
    
    try:
        logger.info('Loading remediation script for s3 Bucket ACL')
        logger.info( 'Event to be remediated {}'.format(event))
        logger.info('Remediating '+event['resource']['id']+' in region '+event['resource']['region'])
        
        
        generateAndSendRemediationOutput = False
        
        cloud_provider_config = {}
        for eventKeys in event:
            if(eventKeys == "cloud_provider_config"):
                generateAndSendRemediationOutput = True
                cloud_provider_config = event['cloud_provider_config']
                logger.info(eventKeys)
                break
            
        remediation_output_message = {}
        
        if (generateAndSendRemediationOutput):
            logger.info('Remediation Cloud Provider Configuration : ' + json.dumps(cloud_provider_config))
            remediation_check_map = dict()
            remediation_output_message["payload_id"] = event["payload_id"]
            remediation_output_message["remediated_checks"] = []
        else:
            logger.info('Remediation Cloud Provider Configuration Not Provided')
        
        Remediate = False
        
        for check in event["checks"]:
            if(check["id"].lower() == "85be9a17-bfd9-4372-be7e-f10834088013"):
                if(generateAndSendRemediationOutput):
                    remediation_check_obj = {}
                    remediation_check_map["85be9a17-bfd9-4372-be7e-f10834088013"]=remediation_check_obj
                    remediation_check_obj["id"] = check["id"]
                    remediation_check_obj["status"] = 0
                    remediation_check_obj["version"] = check["version"]
                
                Remediate = True
                
        if(Remediate):
            bucket = event['resource']['name']
            region = event['resource']['region']
            remediation_status,errorMessage = remediation_handler(region,bucket)
    
            if (remediation_status):
                for k in remediation_check_map:
                    if k.lower() == "85be9a17-bfd9-4372-be7e-f10834088013":
                        remediation_check_obj = remediation_check_map['85be9a17-bfd9-4372-be7e-f10834088013']
                        remediation_check_obj['status']=0
                        remediation_check_obj['message']='Remediated Succesfully from AWS Lambda'
                        remediation_output_message["remediated_checks"].append(remediation_check_obj)
            else:
                for k in remediation_check_map:
                    if(k.lower() == "85be9a17-bfd9-4372-be7e-f10834088013"):
                        remediation_check_obj = remediation_check_map['85be9a17-bfd9-4372-be7e-f10834088013']
                        remediation_check_obj['status']=1
                        remediation_check_obj['message']=errorMessage
                        remediation_output_message["remediated_checks"].append(remediation_check_obj)                
                logger.info("remediation unsuccessful")
        else:
            logger.info("nothing to do")

        if(generateAndSendRemediationOutput):
            remediation_output_message_str = json.dumps(remediation_output_message)
            logger.info('Remediation Output Message Generated : ' + remediation_output_message_str)
            remediation_output_message_str_json = prepareSNSJsonMessage(remediation_output_message_str)
            raise_sns_notification(cloud_provider_config['output_sns_topic_arn'],cloud_provider_config['output_sns_region'],remediation_output_message_str_json,'json')
            logger.info('Remediation Output Message Published Succesfully to SNS.')
                
        return {
        'statusCode': 200,
        'body': json.dumps('Remediation executed successfully')
        }
    except:
        logger.info("unknown exception:", str(sys.exc_info()[0]))
        raise


def remediation_handler(region,bucket):
    
    """
    Remediation handler to enable logging with neccessary permissions to log delivery group
    """
    
    TARGET_BUCKET = os.environ.get("TARGET_BUCKET")
    TARGET_PREFIX = os.environ.get("TARGET_PREFIX")
    
    """ Conditional execution to enable logging only if TARGET_BUCKET and source bucket exists in same region """
    

    if TARGET_BUCKET is not None:
        try:
            s3 = boto3.client('s3',region_name=region)
            resource = boto3.resource('s3')
            target_bucket = resource.Bucket(TARGET_BUCKET)
            if target_bucket.creation_date:
                logger.info("Bucket exists")
                bucket_status = True
            else:
                logger.info("Bucket does not exist")
                bucket_status = False
            #Get current ACL for the bucket
            if bucket_status:
                get_acl = s3.get_bucket_acl(Bucket=TARGET_BUCKET)
                Grants = get_acl['Grants']
                
                logging_acl =[{'Grantee': {'Type': 'Group', 'URI': 'http://acs.amazonaws.com/groups/s3/LogDelivery'}, 'Permission': 'READ_ACP'},
                              {'Grantee': {'Type': 'Group', 'URI': 'http://acs.amazonaws.com/groups/s3/LogDelivery'}, 'Permission': 'WRITE'}]
                
                for Grant in Grants:
                    if (Grant['Permission'] == 'FULL_CONTROL') and (Grant['Grantee'] == {'Type': 'Group', 'URI': 'http://acs.amazonaws.com/groups/s3/LogDelivery'}):
                        logger.info("Not editing log group permissions")
                    else:
                        logging_acl_condition = True
                
                if logging_acl_condition:
                    Grants = Grants + logging_acl

                AccessControlPolicy = {'Owner': get_acl['Owner'], 'Grants': Grants}
                put_acl = s3.put_bucket_acl(Bucket=TARGET_BUCKET, AccessControlPolicy=AccessControlPolicy)
                enable_logging = s3.put_bucket_logging(Bucket=bucket, BucketLoggingStatus={'LoggingEnabled': {'TargetBucket': TARGET_BUCKET,'TargetPrefix': TARGET_PREFIX}})
                
                if(enable_logging['ResponseMetadata']['HTTPStatusCode'] == 200):
                    message = "logging is enabled on Bucket {}".format(bucket)
                    print(message)
                    return True,message
                else:
                    message = "logging is not enabled"
                    return False,message
            else:
                logger.error(" Make sure the target bucket exists and is in the same region as source bucket")
                return False, "Make sure the target bucket exists and is in the same region as source bucket"
            
        
        except ClientError as e:
            logger.error("Encountered client error {}".format(e))
            return False, "Client error encountered"
        except Exception as e:
            return False, ("Unexpected error encountered {}".format(e))
            print(e)
            print("Unexpected error:", str(sys.exc_info()[0]))
            


    
