import json
import sys

def do_remediation(payload):
    print('Default Remediation handler called, payload')
    print(payload)
    