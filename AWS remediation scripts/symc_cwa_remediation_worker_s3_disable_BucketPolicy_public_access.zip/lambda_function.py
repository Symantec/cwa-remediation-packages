"""
    CheckNames: Disable Global PUT Permissions on S3 Bucket,
                Disable Global LIST Permissions on S3 Bucket,
                Disable Global GET Permissions on S3 Bucket,
                Disable Global DELETE Permissions on S3 Bucket
"""
import json
import boto3
import sys
import re
from raise_sns_notification import *
import logging
from botocore.exceptions import ClientError
from copy import copy, deepcopy



""" Initializing logger and setting log level """

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    
    """ Main lambda handler responsible for listening to event and
        creating output sns notification."""
    
    try:
        logger.info('Loading remediation script for s3 Bucket ACL')
        logger.info( 'Event to be remediated {}'.format(event))
        logger.info('Remediating '+event['resource']['id']+' in region '+event['resource']['region'])
        
        generateAndSendRemediationOutput = False
        
        cloud_provider_config = {}
        for eventKeys in event:
            if(eventKeys == "cloud_provider_config"):
                generateAndSendRemediationOutput = True
                cloud_provider_config = event['cloud_provider_config']
                logging.info('Event keys are {}'. format(eventKeys))
                break
            
        remediation_output_message = {}
        
        if (generateAndSendRemediationOutput):
            logging.info('Remediation Cloud Provider Configuration : ' + json.dumps(cloud_provider_config))
            remediation_check_map = dict()
            remediation_output_message["payload_id"] = event["payload_id"]
            remediation_output_message["remediated_checks"] = []
        else:
            logging.debug('Remediation Cloud Provider Configuration Not Provided')
        
        change_acl_permissions = False
        
        permissions = []
        checks = []
        
        for check in event["checks"]:
            if(check["id"].lower() == "58385f1b-abcc-4744-b74e-7acd1fdd0f38"):
                if(generateAndSendRemediationOutput):
                    remediation_check_obj = {}
                    remediation_check_map["58385f1b-abcc-4744-b74e-7acd1fdd0f38"]=remediation_check_obj
                    remediation_check_obj["id"] = check["id"]
                    remediation_check_obj["status"] = 0
                    remediation_check_obj["version"] = check["version"]
                
                permissions.append("Get")
                checks.append(check["id"])

                
            if(check["id"].lower() == "59ac6184-ec22-43fc-a665-70aa10ccb829"):
                if(generateAndSendRemediationOutput):
                    remediation_check_obj = {}
                    remediation_check_map["59ac6184-ec22-43fc-a665-70aa10ccb829"]=remediation_check_obj
                    remediation_check_obj["id"] = check["id"]
                    remediation_check_obj["status"] = 0
                    remediation_check_obj["version"] = check["version"]
                
                permissions.append("List")
                checks.append(check["id"])

            if(check["id"].lower() == "8788f452-8227-4753-889c-c93851ef90c1"):
                if(generateAndSendRemediationOutput):
                    remediation_check_obj = {}
                    remediation_check_map["8788f452-8227-4753-889c-c93851ef90c1"]=remediation_check_obj
                    remediation_check_obj["id"] = check["id"]
                    remediation_check_obj["status"] = 0
                    remediation_check_obj["version"] = check["version"]
                
                permissions.append("Put")
                checks.append(check["id"])
            

            if(check["id"].lower() == "f0de9b72-4327-44b1-ad41-f34fe8b4b975"):
                if(generateAndSendRemediationOutput):
                    remediation_check_obj = {}
                    remediation_check_map["f0de9b72-4327-44b1-ad41-f34fe8b4b975"]=remediation_check_obj
                    remediation_check_obj["id"] = check["id"]
                    remediation_check_obj["status"] = 0
                    remediation_check_obj["version"] = check["version"]
                
                permissions.append("Delete")
                checks.append(check["id"])
                
            
                
        if len(permissions) != 0:
            bucket = event['resource']['name']
            logging.info('Bucket name is {}'.format(bucket))
            region = event['resource']['region']
            logging.info('Bucket region is {}'.format(region))
            remediation_status, errorMessage = delete_permission(region,bucket)

            print(remediation_check_map)
            

        
            if (remediation_status):
                for k in remediation_check_map:
                    for check in checks:
                        if(k.lower() == check):
                            remediation_check_obj = remediation_check_map[check]
                            remediation_check_obj['status']=0
                            remediation_check_obj['message']='Remediated Succesfully from AWS Lambda'
                            remediation_output_message["remediated_checks"].append(remediation_check_obj)
            else:
                for k in remediation_check_map:
                    for check in checks:
                        if(k.lower() == checks):
                            remediation_check_obj = remediation_check_map[check]
                            remediation_check_obj['status']=1
                            remediation_check_obj['message']=errorMessage
                            remediation_output_message["remediated_checks"].append(remediation_check_obj)                
                logging.error("Remediation unsuccessful")
        else:
            logging.info("Nothing to Remediate")

        if(generateAndSendRemediationOutput):
            remediation_output_message_str = json.dumps(remediation_output_message)
            logging.info('Remediation Output Message Generated : ' + remediation_output_message_str)
            remediation_output_message_str_json = prepareSNSJsonMessage(remediation_output_message_str)
            raise_sns_notification(cloud_provider_config['output_sns_topic_arn'],cloud_provider_config['output_sns_region'],remediation_output_message_str_json,'json')
            logging.info('Remediation Output Message Published Succesfully to SNS.')
                
        return {
        'statusCode': 200,
        'body': json.dumps('Remediation script executed successfully')
        }
    except:
        print("unknown exception:", str(sys.exc_info()[0]))
        raise

def delete_permission(region,bucket):
    try:
        s3 = boto3.client('s3',region_name=region)
        get_policy = s3.get_bucket_policy(Bucket=bucket)
        current_policy = json.loads(get_policy['Policy'])
        current_statements = current_policy['Statement']
        new_statements = []
        for statement in current_statements:
            if statement['Effect'] == 'Allow' and isinstance(statement['Action'],str) and re.search(r'.*s3\:Get.*|.*s3\:Delete.*|.*s3\:List.*|.*s3\:Put.*', statement['Action']) and ((statement['Principal'] == {'AWS': '*'}) or (statement['Principal'] == '*')):
                statement['Effect'] = 'Deny'
                new_statements.append(statement)
            elif statement['Effect'] == 'Allow' and isinstance(statement['Action'],list) and ((statement['Principal'] == {'AWS': '*'}) or (statement['Principal'] == '*')):
                allow_permissions, deny_permissions = permission_split(statement['Action'])
                temp_statements= statement.copy()
                if len(allow_permissions) > 0:
                    temp_statements['Action'] = allow_permissions
                    temp_statements['Effect'] = 'Allow'
                    new_statements.append(temp_statements)
                if len(deny_permissions) > 0:
                    statement['Action'] = deny_permissions
                    statement['Effect'] = 'Deny'
                    new_statements.append(statement)
            elif statement['Effect'] == 'Allow' and isinstance(statement['Action'],str) and statement['Action'] == 's3:*'  and ((statement['Principal'] == {'AWS': '*'}) or (statement['Principal'] == '*')):
                statement['Effect'] = 'Deny'
                new_statements.append(statement)
            else:
                new_statements.append(statement)
        
        print(new_statements)
        current_policy['Statement'] = new_statements
        new_policy = json.dumps(current_policy)
        
        """ Deleting current bucket policy """
        response = s3.delete_bucket_policy(Bucket=bucket)
        

        """ Attaching new compliant policy """
        change_bucket_policy = s3.put_bucket_policy(Bucket=bucket,Policy=(new_policy))
        print(change_bucket_policy)
        if change_bucket_policy['ResponseMetadata']['HTTPStatusCode'] == 204:
            Message = ("Bucket policy attached on bucket: {}".format(bucket))
            return True, Message
        else:
            Message = "Unable to update bucket policy"
            return False, Message
    except ClientError as e:
        logger.error("Encountered client error {}".format(e))
        return False, ("Client error encountered {}".format(e))
    except Exception as e:
        print(e)
        print("Unexpected error:", str(sys.exc_info()[0]))
        return False, ("Unexpected error encountered {}".format(e))

def permission_split(actions):
    """ Helper function to split permissions to allowed and not allowed according to policy """
    allow_permissions = []
    deny_permissions = []
    for action in actions:
        if (re.search(r'.*s3\:Get.*|.*s3\:Delete.*|.*s3\:List.*|.*s3\:Put.*', action)):
            deny_permissions.append(action)
        else:
            allow_permissions.append(action)
    return allow_permissions, deny_permissions
    