"""
    CheckNames: Disable Global Edit ACL Permissions on S3 Bucket, 
                Disable Global List ACL Permissions on S3 Bucket, 
                Disable Global View ACL Permissions on S3 Bucket, 
                Disable Global ACL Permissions on S3 Bucket, 
                Disable Global Upload and Delete ACL Permissions on S3 Bucket
"""
import json
import boto3
import sys
from raise_sns_notification import *
import logging
from botocore.exceptions import ClientError


""" Initializing logger and setting log level """

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    
    """ Main lambda handler responsible for listening to event and
        creating output sns notification."""
    
    try:
        logger.info('Loading remediation script for s3 Bucket ACL')
        logger.info( 'Event to be remediated {}'.format(event))
        logger.info('Remediating '+event['resource']['id']+' in region '+event['resource']['region'])
        
        generateAndSendRemediationOutput = False
        
        cloud_provider_config = {}
        for eventKeys in event:
            if(eventKeys == "cloud_provider_config"):
                generateAndSendRemediationOutput = True
                cloud_provider_config = event['cloud_provider_config']
                logging.info('Event keys are {}'. format(eventKeys))
                break
            
        remediation_output_message = {}
        
        if (generateAndSendRemediationOutput):
            logging.info('Remediation Cloud Provider Configuration : ' + json.dumps(cloud_provider_config))
            remediation_check_map = dict()
            remediation_output_message["payload_id"] = event["payload_id"]
            remediation_output_message["remediated_checks"] = []
        else:
            logging.debug('Remediation Cloud Provider Configuration Not Provided')
        
        change_acl_permissions = False
        
        permissions = []
        checks = []
        
        for check in event["checks"]:
            if(check["id"].lower() == "f5478d86-9213-44bb-a9c1-1ccacd405745"):
                if(generateAndSendRemediationOutput):
                    remediation_check_obj = {}
                    remediation_check_map["f5478d86-9213-44bb-a9c1-1ccacd405745"]=remediation_check_obj
                    remediation_check_obj["id"] = check["id"]
                    remediation_check_obj["status"] = 0
                    remediation_check_obj["version"] = check["version"]
                
                permissions.append("READ")
                checks.append(check["id"])

                
            if(check["id"].lower() == "5cee37ca-342f-4f3b-9743-de9380bf998e"):
                if(generateAndSendRemediationOutput):
                    remediation_check_obj = {}
                    remediation_check_map["5cee37ca-342f-4f3b-9743-de9380bf998e"]=remediation_check_obj
                    remediation_check_obj["id"] = check["id"]
                    remediation_check_obj["status"] = 0
                    remediation_check_obj["version"] = check["version"]
                
                permissions.append("WRITE")
                checks.append(check["id"])

            if(check["id"].lower() == "513fae94-ac45-4e22-8c16-7d823586f1ee"):
                if(generateAndSendRemediationOutput):
                    remediation_check_obj = {}
                    remediation_check_map["513fae94-ac45-4e22-8c16-7d823586f1ee"]=remediation_check_obj
                    remediation_check_obj["id"] = check["id"]
                    remediation_check_obj["status"] = 0
                    remediation_check_obj["version"] = check["version"]
                
                permissions.append("WRITE_ACP")
                checks.append(check["id"])
            

            if(check["id"].lower() == "6440c803-2039-49e2-8535-a7ce38b3b440"):
                if(generateAndSendRemediationOutput):
                    remediation_check_obj = {}
                    remediation_check_map["6440c803-2039-49e2-8535-a7ce38b3b440"]=remediation_check_obj
                    remediation_check_obj["id"] = check["id"]
                    remediation_check_obj["status"] = 0
                    remediation_check_obj["version"] = check["version"]
                
                permissions.append("READ_ACP")
                checks.append(check["id"])
                
                print(remediation_check_map)


            if(check["id"].lower() == "6b45aea0-1943-41c3-a818-f6ce91900223"):
                if(generateAndSendRemediationOutput):
                    remediation_check_obj = {}
                    remediation_check_map["6b45aea0-1943-41c3-a818-f6ce91900223"]=remediation_check_obj
                    remediation_check_obj["id"] = check["id"]
                    remediation_check_obj["status"] = 0
                    remediation_check_obj["version"] = check["version"]
                
                permissions.append("WRITE_ACP")
                permissions.append("READ_ACP")                
                checks.append(check["id"])
                
                print(remediation_check_map)

            
                
        if len(permissions) != 0:
            bucket = event['resource']['name']
            logging.info('Bucket name is {}'.format(bucket))
            region = event['resource']['region']
            logging.info('Bucket region is {}'.format(region))
            remediation_status, errorMessage = delete_permission(region,bucket,permissions)
                            
            print(remediation_check_map)

            
            
            if (remediation_status):
                for k in remediation_check_map:
                    for check in checks:
                        if(k.lower() == check):
                            remediation_check_obj = remediation_check_map[check]
                            remediation_check_obj['status']=0
                            remediation_check_obj['message']='Remediated Succesfully from AWS Lambda'
                            remediation_output_message["remediated_checks"].append(remediation_check_obj)
            else:
                for k in remediation_check_map:
                    for check in checks:
                        if(k.lower() == checks):
                            remediation_check_obj = remediation_check_map[check]
                            remediation_check_obj['status']=1
                            remediation_check_obj['message']=errorMessage
                            remediation_output_message["remediated_checks"].append(remediation_check_obj)                
                logging.error("Remediation unsuccessful")
        else:
            logging.info("Nothing to Remediate")

        if(generateAndSendRemediationOutput):
            remediation_output_message_str = json.dumps(remediation_output_message)
            logging.info('Remediation Output Message Generated : ' + remediation_output_message_str)
            remediation_output_message_str_json = prepareSNSJsonMessage(remediation_output_message_str)
            raise_sns_notification(cloud_provider_config['output_sns_topic_arn'],cloud_provider_config['output_sns_region'],remediation_output_message_str_json,'json')
            logging.info('Remediation Output Message Published Succesfully to SNS.')
                
        return {
        'statusCode': 200,
        'body': json.dumps('Remediation script executed successfully')
        }
    except:
        print("unknown exception:", str(sys.exc_info()[0]))
        raise

def delete_permission(region,bucket,permissions):
    
    """ Fetches the current configuration there can be four types of public access
        Read - Access to objects for all aws users
        write - Access to write objetcs for all aws users
        Read_ACP - Access to read ACL for all aws users
        Write_ACP - Access to write ACL for all aws users """
    
    try:
        s3 = boto3.client('s3',region_name=region)
        """ Get current ACL for the bucket """
        get_acl = s3.get_bucket_acl(Bucket=bucket)
        Grants = (get_acl['Grants'])
        print("old {}".format(Grants))
        new_Grants = []
        
        """ Full control variable to deal with individual ACL permissions """
        full_control = [{'Grantee': {'Type': 'Group', 'URI': 'http://acs.amazonaws.com/groups/global/AllUsers'}, 'Permission': 'READ'},
                        {'Grantee': {'Type': 'Group', 'URI': 'http://acs.amazonaws.com/groups/global/AllUsers'}, 'Permission': 'WRITE'},
                        {'Grantee': {'Type': 'Group', 'URI': 'http://acs.amazonaws.com/groups/global/AllUsers'},'Permission': 'READ_ACP'},
                        {'Grantee': {'Type': 'Group', 'URI': 'http://acs.amazonaws.com/groups/global/AllUsers'}, 'Permission': 'WRITE_ACP'}]
                        
        for Grant in Grants:
            if (Grant['Permission'] == 'FULL_CONTROL') and (Grant['Grantee'] == {'Type': 'Group', 'URI': 'http://acs.amazonaws.com/groups/global/AllUsers'}):
                Grants.remove(Grant)
                Grants = Grants + full_control
        
        logging.info("Current Grants for the bucket ACL are {}".format(Grants))
        
        
        for i,Grant in enumerate(Grants):
            if (Grant['Permission'] in permissions) and (Grant['Grantee'] == {'Type': 'Group', 'URI': 'http://acs.amazonaws.com/groups/global/AllUsers'}):
                print("old Grant {} will be deleted for remediation".format(Grant))
            else:
                new_Grants.append(Grant)
        logging.info("New Grants after remediation for the bucket ACL are {}".format(new_Grants))
        
        print("new {}".format(Grants))
        
        """ AccessControlPolicy to make sure that permissions other than Public are not removed """
        
        AccessControlPolicy = {'Owner': get_acl['Owner'], 'Grants': new_Grants}
        put_acl = s3.put_bucket_acl(Bucket=bucket, AccessControlPolicy=AccessControlPolicy)
        
        if put_acl['ResponseMetadata']['HTTPStatusCode'] == 200:
            Message = "Bucket ACL for public access is blocked for remediation enabled checks"
            print(Message)
            return True, Message
        else:
            Message = "Bucket ACL has not been updated"
            return False, Message
    except ClientError as e:
        logger.error("Encountered client error {}".format(e))
        return False, "Client error encountered"
    except Exception as e:
        print(e)
        return False, ("Unknown exception {} occured".format(e))
        
        