"""
CheckName: Ensure the S3 bucket CloudTrail logs to is not publicly accessible
CheckID: 0CA26F89-AACD-420F-9C79-CA67C24E89C6
"""

import json
import boto3
import sys
from raise_sns_notification import *
import os
import logging
from botocore.exceptions import ClientError


""" Initializing logger and setting log level """

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    try:
        logger.info("Loading remediation script for s3 acl")
        logger.info(event)
        logger.info('Remediating '+event['resource']['id']+' in region '+event['resource']['region'])
        
        generateAndSendRemediationOutput = False
        
        cloud_provider_config = {}
        for eventKeys in event:
            if(eventKeys == "cloud_provider_config"):
                generateAndSendRemediationOutput = True
                cloud_provider_config = event['cloud_provider_config']
                logger.info(eventKeys)
                break
            
        remediation_output_message = {}
        
        if (generateAndSendRemediationOutput):
            logger.info('Remediation Cloud Provider Configuration : ' + json.dumps(cloud_provider_config))
            remediation_check_map = dict()
            remediation_output_message["payload_id"] = event["payload_id"]
            remediation_output_message["remediated_checks"] = []
        else:
            logger.debug('Remediation Cloud Provider Configuration Not Provided')
        
        change_acl_permissions = False
        
        for check in event["checks"]:
            if(check["id"].lower() == "0ca26f89-aacd-420f-9c79-ca67c24e89c6"):
                if(generateAndSendRemediationOutput):
                    remediation_check_obj = {}
                    remediation_check_map["0ca26f89-aacd-420f-9c79-ca67c24e89c6"]=remediation_check_obj
                    remediation_check_obj["id"] = check["id"]
                    remediation_check_obj["status"] = 0
                    remediation_check_obj["version"] = check["version"]
                
                change_acl_permissions = True
                
                
        if(change_acl_permissions):
            bucket = event['resource']['name']
            logger.info(bucket)
            region = event['resource']['region']
            logger.info(region)
            remediation_status,errorMessage = remediation_handler(region,bucket)
            if (remediation_status):
                for k in remediation_check_map:
                    if k.lower() == "0ca26f89-aacd-420f-9c79-ca67c24e89c6":
                        remediation_check_obj = remediation_check_map['0ca26f89-aacd-420f-9c79-ca67c24e89c6']
                        remediation_check_obj['status']=0
                        remediation_check_obj['message']='Remediated Succesfully from AWS Lambda'
                        remediation_output_message["remediated_checks"].append(remediation_check_obj)
            else:
                for k in remediation_check_map:
                    if(k.lower() == "0ca26f89-aacd-420f-9c79-ca67c24e89c6"):
                        remediation_check_obj = remediation_check_map['0ca26f89-aacd-420f-9c79-ca67c24e89c6']
                        remediation_check_obj['status']=1
                        remediation_check_obj['message']=errorMessage
                        remediation_output_message["remediated_checks"].append(remediation_check_obj)                
                logger.error("remediation unsuccessful")
        else:
            logger.info("nothing to do")

        if(generateAndSendRemediationOutput):
            remediation_output_message_str = json.dumps(remediation_output_message)
            logger.info('Remediation Output Message Generated : ' + remediation_output_message_str)
            remediation_output_message_str_json = prepareSNSJsonMessage(remediation_output_message_str)
            raise_sns_notification(cloud_provider_config['output_sns_topic_arn'],cloud_provider_config['output_sns_region'],remediation_output_message_str_json,'json')
            logger.info('Remediation Output Message Published Succesfully to SNS.')
                
        return {
        'statusCode': 200,
        'body': json.dumps('Remediation script executed successfully')
        }
    except:
        logger.error("unknown exception:", str(sys.exc_info()[0]))
        raise


def remediation_handler(region,bucket):
        try:
            s3 = boto3.resource('s3',region_name=region)
            get_acl= s3.BucketAcl(bucket)
            logger.info("updating ACL for {bucket} in the {region}".format(bucket=bucket,region=region))
            response = get_acl.put(ACL='private')
            if response['ResponseMetadata']['HTTPStatusCode'] == 200 :
                Message = "ACL updated to make bucket private"
                print(Message)
                return True,Message
            else:
                Message = "ACL not updated"
                return False,Message
        except Exception as e:
            print(e)
            logger.info('Error occurred while calling BucketAcl update API ' + str(sys.exc_info()[0]))
            errorMessage = str(sys.exc_info()[0])
            return False,("Exception occured {}".format(e))
        
        